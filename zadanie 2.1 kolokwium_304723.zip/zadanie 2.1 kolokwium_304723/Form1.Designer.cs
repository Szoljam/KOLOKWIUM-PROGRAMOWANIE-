﻿namespace zadanie_2._1_kolokwium_304723
{
    partial class Form1
    {
        /// <summary>
        ///  Required designer variable.
        /// </summary>
        private System.ComponentModel.IContainer components = null;

        /// <summary>
        ///  Clean up any resources being used.
        /// </summary>
        /// <param name="disposing">true if managed resources should be disposed; otherwise, false.</param>
        protected override void Dispose(bool disposing)
        {
            if (disposing && (components != null))
            {
                components.Dispose();
            }
            base.Dispose(disposing);
        }

        #region Windows Form Designer generated code

        /// <summary>
        ///  Required method for Designer support - do not modify
        ///  the contents of this method with the code editor.
        /// </summary>
        private void InitializeComponent()
        {
            label1 = new Label();
            textBoxWiek = new TextBox();
            buttonOblicz = new Button();
            label2 = new Label();
            textBoxWynik = new TextBox();
            SuspendLayout();
            // 
            // label1
            // 
            label1.AutoSize = true;
            label1.Location = new Point(12, 9);
            label1.Name = "label1";
            label1.Size = new Size(100, 25);
            label1.TabIndex = 0;
            label1.Text = "Podaj wiek:";
            // 
            // textBoxWiek
            // 
            textBoxWiek.Location = new Point(12, 37);
            textBoxWiek.Name = "textBoxWiek";
            textBoxWiek.Size = new Size(150, 31);
            textBoxWiek.TabIndex = 1;
            // 
            // buttonOblicz
            // 
            buttonOblicz.Location = new Point(12, 74);
            buttonOblicz.Name = "buttonOblicz";
            buttonOblicz.Size = new Size(150, 34);
            buttonOblicz.TabIndex = 2;
            buttonOblicz.Text = "Oblicz";
            buttonOblicz.UseVisualStyleBackColor = true;
            buttonOblicz.Click += button1_Click;
            // 
            // label2
            // 
            label2.AutoSize = true;
            label2.Location = new Point(12, 122);
            label2.Name = "label2";
            label2.Size = new Size(70, 25);
            label2.TabIndex = 3;
            label2.Text = "Wynik: ";
            // 
            // textBoxWynik
            // 
            textBoxWynik.Location = new Point(12, 150);
            textBoxWynik.Name = "textBoxWynik";
            textBoxWynik.ReadOnly = true;
            textBoxWynik.Size = new Size(317, 31);
            textBoxWynik.TabIndex = 4;
            // 
            // Form1
            // 
            AutoScaleDimensions = new SizeF(10F, 25F);
            AutoScaleMode = AutoScaleMode.Font;
            ClientSize = new Size(800, 450);
            Controls.Add(textBoxWynik);
            Controls.Add(label2);
            Controls.Add(buttonOblicz);
            Controls.Add(textBoxWiek);
            Controls.Add(label1);
            Name = "Form1";
            Text = "Form1";
            ResumeLayout(false);
            PerformLayout();
        }

        #endregion

        private Label label1;
        private TextBox textBoxWiek;
        private Button buttonOblicz;
        private Label label2;
        private TextBox textBoxWynik;
    }
}
