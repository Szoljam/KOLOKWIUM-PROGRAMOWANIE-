namespace zadanie_2._1_kolokwium_304723
{
    public partial class Form1 : Form
    {
        public Form1()
        {
            InitializeComponent();
        }

        private void button1_Click(object sender, EventArgs e)
        {
            string wpisanyTekst = textBoxWiek.Text;

            if (int.TryParse(wpisanyTekst, out int wiek))
            {
                if (wiek >= 18)
                {
                    textBoxWynik.Text = "Witaj, jesteś pełnoletni.";
                }
                else
                {
                    textBoxWynik.Text = "Niestety jeszcze nie jesteś pełnoletni.";
                }
            }
            else
            {
                MessageBox.Show("Podano nieprawidłową wartość. Wpisz liczbę całkowitą.", "Błąd", MessageBoxButtons.OK, MessageBoxIcon.Error);
                textBoxWynik.Text = "Błąd danych!";
            }
        }
    }
}
